// Copyright (c) Microsoft Corporation.
#pragma once
#ifdef __cplusplus
#include <__msvc_cxx_stdatomic.hpp>
#else
#include <vcruntime_c11_stdatomic.h>
#endif